﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ability : MonoBehaviour
{
    public float checkradius;
    bool playerisnear;
    public LayerMask whatisotherplayers;
    private CharacterController2D characterController2D;
    public float increasto = 1000f;
    public float resetto = 700f;

    // Start is called before the first frame update
    void Start()
    {
        characterController2D = GetComponent<CharacterController2D>();
    }

    // Update is called once per frame
    void Update()
    {
        playerisnear = Physics2D.OverlapCircle(transform.position, checkradius, whatisotherplayers);
        
        if(playerisnear == true)
        {
            characterController2D.m_JumpForce = increasto;
        }
        if(playerisnear == false)
        {
            characterController2D.m_JumpForce = resetto;
            playerisnear = false;
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, checkradius);
    }
}
