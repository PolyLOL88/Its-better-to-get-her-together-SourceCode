﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class Enemy : MonoBehaviour
{
	public int health = 100;
	public AIPatrol ai;
	public TMP_Text bosstext;

	public void TakeDamage(int damage)
	{
		health -= damage;

		if (health <= 0)
		{
			Die();
		}
	}

	void Die()
	{
		Destroy(gameObject);
		FindObjectOfType<AudioManager>().Play("Win");
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
	}

	private void Update()
	{
		if (health == 80)
		{
			ai.speed = 8f;
		}

		if (health == 50)
		{
			ai.speed = 10f;
		}

		bosstext.text = "Boss Lives:" + health;
	}
}
