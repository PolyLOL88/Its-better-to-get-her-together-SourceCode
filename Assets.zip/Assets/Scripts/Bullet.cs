﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Bullet : MonoBehaviour
{
    public float speed;

    private Transform player;
    private Vector2 targte;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        targte = new Vector2(player.position.x, player.position.y);
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector2.MoveTowards(transform.position, targte, speed * Time.deltaTime);

        if(transform.position.x == targte.x && transform.position.y == targte.y)
        {
            Destroy(gameObject);
        }

        if(targte == null)
        {
            Dead();
        }

        if (player == null)
        {
            Dead();
        }


    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Destroy(gameObject);
            FindObjectOfType<AudioManager>().Play("Bum");
        }
        else if (other.CompareTag("Tim"))
        {
            Destroy(gameObject);
            FindObjectOfType<AudioManager>().Play("Bum");
        }
        if(other.CompareTag("Solid"))
        {
            Destroy(gameObject);
        }
    }
    
    void Dead()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
