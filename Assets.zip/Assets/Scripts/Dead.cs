﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Dead : MonoBehaviour
{
    public float restartdelay;
    //private Shake shake;

    /*private void Start()
    {
        shake = GameObject.FindGameObjectWithTag("Shake").GetComponent<Shake>();
    }*/

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Destroy(other.gameObject);
            FindObjectOfType<AudioManager>().Play("Bum");
            //shake.CamShake();
            Invoke("LoadLevelAgain", restartdelay);
        }
        /*else if (other.CompareTag("Tim"))
        {
            Destroy(other.gameObject);
            FindObjectOfType<AudioManager>().Play("Bum");
            //shake.CamShake();
            Invoke("LoadLevelAgain", restartdelay);
        }*/
    }

    void LoadLevelAgain()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
