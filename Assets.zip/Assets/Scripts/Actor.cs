﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
using UnityEngine.SceneManagement;

public class Actor : MonoBehaviour
{
    public Playermovement playermovementtim;
    public Playermovement playermovementtom;
    public GameObject TomCam;
    public GameObject TimCam;
    /*public GameObject albertcam;
    public Shooting shooting;
    public Playermovement albertmovement;*/

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            TimCam.SetActive(true);
            TomCam.SetActive(false);
            //albertcam.SetActive(false);
            playermovementtim.enabled = true;
            playermovementtom.enabled = false;
            //albertmovement.enabled = false;
        }
        else if (Input.GetButtonDown("Fire2"))
        {
            TomCam.SetActive(true);
            TimCam.SetActive(false);
            //albertcam.SetActive(false);
            playermovementtim.enabled = false;
            playermovementtom.enabled = true;
            //albertmovement.enabled = false;
        }

        /*if (Input.GetButtonDown("Fire5"))
        {
            albertcam.SetActive(true);
            TomCam.SetActive(false);
            TimCam.SetActive(false);
            playermovementtim.enabled = false;
            playermovementtom.enabled = false;
            albertmovement.enabled = true;
        }*/

        if (playermovementtim == null)
        {
            Invoke("Dead", 1f);
            FindObjectOfType<AudioManager>().Play("Bum");
        }

        if (playermovementtom== null)
        {
            Invoke("Dead", 1f);
            FindObjectOfType<AudioManager>().Play("Bum");
        }
    }

    void Dead()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }


}
