﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate : MonoBehaviour
{
    private void Update()
    {
        if (Input.GetButtonDown("Fire3"))
        {
            transform.rotation = Quaternion.Euler(0f, 0f, 90f);
        }
        if (Input.GetButtonDown("Fire4"))
        {
            transform.rotation = Quaternion.Euler(0f, 0f, 0f);
        }
    }
}
