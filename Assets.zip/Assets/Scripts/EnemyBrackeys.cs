﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBrackeys : MonoBehaviour
{
    public GameObject bullet;
    private Transform target;
    private float timebtwshots;
    public float starttimebtwshots;

    private void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").transform;
        timebtwshots = starttimebtwshots;
    }

    private void Update()
    {
        if(timebtwshots <= 0)
        {
            Instantiate(bullet, transform.position, Quaternion.identity);
            timebtwshots = starttimebtwshots;
        }
        else
        {
            timebtwshots -= Time.deltaTime;
        }
       
    }
}
